/*
 * crackme-easy-keygen.c
 * Password generator for crackme-easy-1
 * Author: Gabriel Marti
 * Twitter: @H0l3Bl4ck
 */
#include <stdio.h>

int calc_string(char *string_pointer) {
  char current_char;
  int char_count;
  int calc_result;
  int string_len;
  
  /* length of string */
  string_len = 0;
  calc_result = 0;
  current_char = *string_pointer;
  while (current_char != '\0') {
    string_len++;
    current_char = string_pointer[string_len];
  }
  
  /* calc string */
  string_len--;
  if (-1 < string_len) {
    char_count = 0;
    do {
        /* The result of the previous calculation is multiplied by 64, then the ASCII
           value of the current character is added and the module (remainder) of the
           division by 10000000 is obtained, storing this value for the next iteration.
        */
        calc_result = ((int)string_pointer[char_count] + calc_result * 0x40) % 10000000;
        char_count++;
    } while ((int)char_count <= string_len);
  }
  return calc_result;
}


int main(int argc, char **argv)
{
    int key = 0x54a337;
    int calc_key;
    char c1, c2, c3, c4, first, last;
    char pass[5];
     
    pass[4] = '\0';
    printf("Searching possible passwords for key %X ...\n\n", key);
    first = '!';
    last = '}';
       
    for (c1 = first; c1 <= last; c1++) {
        for (c2 = first; c2 <= last; c2++) {
            for (c3 = first; c3 <= last; c3++) {
                for (c4 = first; c4 <= last; c4++) {
                    pass[0] = c1;
                    pass[1] = c2;
                    pass[2] = c3;
                    pass[3] = c4;
                    calc_key = calc_string(pass);
                    if ( calc_key == key ) {
                        printf("Password for key %X is %s \n", calc_key, pass);
                    }
                }
            }
        }
    }
    return 0;
}
